import "./App.css";
import LoginSignup from "./components/LoginSignup/LoginSignup";

function App() {
  return <LoginSignup />;
}

export default App;
