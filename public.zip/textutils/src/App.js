import "./App.css";
import Navbar from "./components/Navbar";
import TextF from "./components/TextF";

function App() {
  return (
    <>
      {/* <Navbar title="Textutils" aboutText="About TextUtils" /> */}
      {/* <Navbar />  */}
      <Navbar title="Textutils" />
      <div className="container my-3">
        <TextF heading="Enter The Text To Analize Below" />
      </div>
    </>
  );
}

export default App;
